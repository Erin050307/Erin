//===================[ TEMPAT MODULE ]=====================\\
require("./config")
require('./lib/menu')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType, useMultiFileAuthState, makeWASocket, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaSocket } = require("@adiwajshing/baileys")
const fs = require('fs')
const util = require('util')
const axios = require('axios')
const { exec } = require("child_process")
const { performance } = require('perf_hooks')
const speed = require('performance-now')
const chalk = require('chalk')
const moment = require('moment-timezone');
const os = require('os') 
const didyoumean = require('didyoumean');
const similarity = require('similarity')
const path = require('path')
const ms = require("parse-ms") 
const archiver = require("archiver")
const sharp = require('sharp')
const kotz = require("kotz-api");
const fsx = require('fs-extra')
const toMS = require("ms");
const nou = require("node-os-utils");
const { sizeFormatter } = require("human-readable");
const ytdl = require("node-yt-dl");

module.exports = async (Rifky, m) => {
try {
const from = m.key.remoteJid
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""

//==================[ TEMPAT CONST LIB ]=====================\\
const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, isUrl, hitungmundur, sleep, clockString, runtime, tanggal, formatp, getRandom } = require('./lib/myfunc')
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/respon-list');
const { isSetProses, addSetProses, removeSetProses, changeSetProses, getTextSetProses } = require('./lib/setproses');
const { isSetDone, addSetDone, removeSetDone, changeSetDone, getTextSetDone } = require('./lib/setdone');
const afk = require('./lib/afk');
const kambing = fs.readFileSync('./lib/kambing.jpg')
const { isSetOpen, addSetOpen, removeSetOpen, changeSetOpen, getTextSetOpen } = require("./lib/setopen");
const { isSetClose, addSetClose, removeSetClose, changeSetClose, getTextSetClose } = require("./lib/setclose");
const { getLimit, isLimit, limitAdd, kurangLimit, giveLimit, addBalance, kurangBalance, getBalance, isGame, gameAdd, givegame, cekGLimit } = require("./lib/limit");
const {
    TelegraPh,
    UploadFileUgu,
    webp2mp4File,
    floNime
} = require('./lib/uploader')
const { limitCount } = require("./database/game/limit.json");
const uploadImage = require('./lib/uploadImage') 


//==================[ TEMPAT CONST SCRAPE ]=====================\\

//===================[ TAMPAT PREFIX / ADMIN / OWNER ]====================\\
const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (Rifky.user.id.split(':')[0]+'@s.whatsapp.net' || Rifky.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await Rifky.decodeJid(Rifky.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)

const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const groupMetadata = m.isGroup ? await Rifky.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const qtext = q = args.join(" ")
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
const math = (teks) => {
return Math.floor(teks)
}
const qmsg = (quoted.msg || quoted)
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const _prem = require("./lib/premium");
const _sewa = require("./lib/sewa");
let premium = JSON.parse(fs.readFileSync('./database/premium.json'));
let sewa = JSON.parse(fs.readFileSync('./database/sewa.json'));
const isPremium = isCreator ? true : _prem.checkPremiumUser(m.sender, premium)
_prem.expiredCheck(Rifky, premium)
const isSewa = _sewa.checkSewaGroup(m.chat, sewa)
_sewa.expiredCheck(Rifky, sewa)

//=================[ TEMPAT FUNCTION DATABASE ]====================\\
let db_respon_list = JSON.parse(fs.readFileSync('./database/list-message.json'));
let listStore = JSON.parse(fs.readFileSync('./database/list-message.json'));
let set_proses = JSON.parse(fs.readFileSync('./database/set_proses.json'));
let set_done = JSON.parse(fs.readFileSync('./database/set_done.json'));
let _afk = JSON.parse(fs.readFileSync('./database/afk.json'));
let set_open = JSON.parse(fs.readFileSync('./database/set_open.json'));
let set_close = JSON.parse(fs.readFileSync('./database/set_close.json'));
let db_balance = JSON.parse(fs.readFileSync("./database/balance.json"));
let db_limit = JSON.parse(fs.readFileSync("./database/limit.json"));
const isAfkOn = afk.checkAfkUser(m.sender, _afk)
const Zip = JSON.parse(fs.readFileSync('./database/zip.json'))

const data_smk = JSON.parse(fs.readFileSync('./database/idgrup.json').toString())
const GroupSekolah = m.isGroup ? data_smk.includes(m.chat) : false
//===================[ TAMPILAN CONSOLE ]=====================\\
if (m.message) {
console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', from))
}


//==================[ FUNCTION FITUR ]=====================\\

global.db = JSON.parse(fs.readFileSync('./database/database.json'))
if (global.db) global.db.data = {
users: {},
chats: {},
others: {},
settings: {},
...(global.db.data || {})
}
// Gak Usah Di Apa Apain Jika Tidak Mau Error
try {
ppuser = await Rifky.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
try {
var ppuser = await Rifky.profilePictureUrl(m.sender, 'image')} catch (err) {
let ppuser = 'https://telegra.ph/file/6880771a42bad09dd6087.jpg'}
let ppnyauser = await getBuffer(ppuser)

// respon list 
if (m.isGroup && isAlreadyResponList(m.chat, body.toLowerCase(), db_respon_list)) {
var get_data_respon = getDataResponList(m.chat, body.toLowerCase(), db_respon_list)
if (get_data_respon.isImage === false) {
Rifky.sendMessage(m.chat, { text: sendResponList(m.chat, body.toLowerCase(), db_respon_list) }, {
quoted: m
})
} else {
Rifky.sendMessage(m.chat, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {
quoted: m
})
}
}
// function resize
const reSize = async(buffer, ukur1, ukur2) => {
   return new Promise(async(resolve, reject) => {
      let jimp = require('jimp')
      var baper = await jimp.read(buffer);
      var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
      resolve(ab)
   })
}
    const fkethmb = await reSize(ppuser, 300, 300)
    // function resize
    let jimp = require("jimp")
const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};

global.public = true
//self public
if (!global.public) {
if (!m.key.fromMe && !isCreator) return
}



let format = sizeFormatter({
std: "JEDEC", // 'SI' (default) | 'IEC' | 'JEDEC'
decimalPlaces: 2,
keepTrailingZeroes: false,
render: (literal, symbol) => `${literal} ${symbol}B`,
});











async function downloadMp3 (link) {
try {
Rifky.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
let kyuu = await fetchJson (`https://api.kyuurzy.site/api/download/aio?query=${link}`)
Rifky.sendMessage(m.chat, { audio: {url: kyuu.result.url}, mimetype: "audio/mpeg"},{ quoted:m})
}catch (err) {
reply(`${err}`)
}
}

//=========================\\

async function getGcName(groupID) {
try {
let data_name = await Rifky.groupMetadata(groupID)
return data_name.subject
} catch (err) {
return '-'
}
}
//=========================\\


Rifky.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
        let type = await Rifky.getFile(path, true)
        let {
            res,
            data: file,
            filename: pathFile
        } = type
        if (res && res.status !== 200 || file.length <= 65536) {
            try {
                throw {
                    json: JSON.parse(file.toString())
                }
            }
            catch (e) {
                if (e.json) throw e.json
            }
        }
        let opt = {
            filename
        }
        if (quoted) opt.quoted = quoted
        if (!type) options.asDocument = true
        let mtype = '',
            mimetype = type.mime,
            convert
        if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker'
        else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image'
        else if (/video/.test(type.mime)) mtype = 'video'
        else if (/audio/.test(type.mime))(
            convert = await (ptt ? toPTT : toAudio)(file, type.ext),
            file = convert.data,
            pathFile = convert.filename,
            mtype = 'audio',
            mimetype = 'audio/ogg; codecs=opus'
        )
        else mtype = 'document'
        if (options.asDocument) mtype = 'document'

        delete options.asSticker
        delete options.asLocation
        delete options.asVideo
        delete options.asDocument
        delete options.asImage

        let message = {
            ...options,
            caption,
            ptt,
            [mtype]: {
                url: pathFile
            },
            mimetype
        }
        let m
        try {
            m = await Rifky.sendMessage(jid, message, {
                ...opt,
                ...options
            })
        }
        catch (e) {
            //console.error(e)
            m = null
        }
        finally {
            if (!m) m = await Rifky.sendMessage(jid, {
                ...message,
                [mtype]: file
            }, {
                ...opt,
                ...options
            })
            file = null
            return m
        }
    }
    
    function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}

const sendzip = (teks) => {
Rifky.sendMessage(from, { document: teks, mimetype: 'application/zip'}, {quoted:m})
}
for (let BossRifky of Zip) {
if (budy === BossRifky) {
let buffer = fs.readFileSync(`./database/zip/${BossRifky}.zip`)
sendzip(buffer)
}
}

function formatSize(bytes) {
    if (bytes >= 1 << 30) return (bytes / (1 << 30)).toFixed(2) + " GB";
    if (bytes >= 1 << 20) return (bytes / (1 << 20)).toFixed(2) + " MB";
    if (bytes >= 1 << 10) return (bytes / (1 << 10)).toFixed(2) + " KB";
    return bytes + " B";
}

// Bandwidth
async function checkBandwidth() {
let ind = 0;
let out = 0;
for (let i of await require("node-os-utils").netstat.stats()) {
ind += parseInt(i.inputBytes);
out += parseInt(i.outputBytes);
}
return {
download: format(ind),
upload: format(out),
};
}
//=========================\\


//=========================\\

         //==================[ FUNCTION GAME ]=====================\\
const tag = `${m.sender.split('@')[0]}`

let usere = `${m.sender.split('@')[0]}`+'@s.whatsapp.net'

function monospace(string) {
return '```' + string + '```'
}

function randomNomor(min, max = null){
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}}

if ((from in tebakbendera)) {
let { soal, jawaban, hadiah, waktu } = tebakbendera[from]
if (budy.toLowerCase() == "nyerah") {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebakbendera[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakbendera[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}

if ((from in susunkata)) {
let { soal, jawaban, hadiah, waktu } = susunkata[from]
if (budy.toLowerCase() == "nyerah") {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete susunkata[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete susunkata[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}

if ((from in tebakanime)) {
let { soal, jawaban, hadiah, waktu } = tebakanime[from]
if (budy.match('nyerah|Nyerah|.nyerah')) {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebakanime[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakanime[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}

if ((from in tebaklagu)) {
let { soal, jawaban, hadiah, waktu } = tebaklagu[from]
if (budy.match('nyerah|Nyerah|.nyerah')) {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebaklagu[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebaklagu[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}

if ((from in kuis)) {
let { soal, jawaban, hadiah, waktu } = kuis[from]
if (budy.match('nyerah|Nyerah|.nyerah')) {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete kuis[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete kuis[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}

if ((from in siapakahaku)) {
let { soal, jawaban, hadiah, waktu } = siapakahaku[from]
if (budy.match('nyerah|Nyerah|.nyerah')) {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete siapakahaku[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete siapakahaku[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}

if ((from in tebakkimia)) {
let { soal, jawaban, hadiah, waktu } = tebakkimia[from]
if (budy.match('nyerah|Nyerah|.nyerah')) {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebakkimia[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakkimia[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}

if ((from in asahotak)) {
let { soal, jawaban, hadiah, waktu } = asahotak[from]
if (budy.match('nyerah|Nyerah|.nyerah')) {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete asahotak[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete asahotak[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}


if ((from in family100)) {
let { soal, jawaban, hadiah, waktu } = family100[from]
for (let i of jawaban){
if (body.toLowerCase().includes(i)) {
let anu = jawaban.indexOf(i)
jawaban.splice(anu, 1)
m.reply(`*GAME FAMILY 100*\n\nJawaban Kamu Benar!\nJawaban : ${i}\nHadiah balance : 5\n\n${jawaban.length < 1 ? 'Semua Jawaban Sudah Tertebak!\nIngin Bermain Lagi? Kirim '+prefix+'family100' : 'Sisa Yang Belum Ditebak : '+jawaban.length}`)
addBalance(usere, 5, db_balance)
}}
if (jawaban.length < 1){
clearTimeout(waktu);
delete family100[from];
}}

if ((from in tebakkata)) {
let { soal, jawaban, hadiah, waktu } = tebakkata[from]
if (budy.match('nyerah|Nyerah|.nyerah')) {
m.reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebakkata[from];
clearTimeout(waktu);
} else if (body.toLowerCase().includes(jawaban)) {
await m.reply(`*JAWABAN BENAR*\n\nPenebak : ${tag}\nJawaban : ${jawaban}\nHadiah balance : 5`);
addBalance(usere, 5, db_balance)
Rifky.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakkata[from];
} else Rifky.sendMessage(m.chat, {react: {text: '🔴', key: m.key}})
}
        //===================[ FUNCTION REPLY ]=====================\\


const reply = (teks) => { 
Rifky.sendMessage(from, { text: teks, contextInfo: { 
"externalAdReply": { 
"showAdAttribution": true, 
"title": "Erin store", 
"containsAutoReply": true, 
"mediaType": 1, 
"thumbnail": kambing, 
"mediaUrl": "https://whatsapp.com/channel/0029VakTtLD9MF94Un9kgJ29", 
"sourceUrl": "https://whatsapp.com/channel/0029VakTtLD9MF94Un9kgJ29" }}}, { quoted: m }) }

const reply2 = (teks) => {
Rifky.sendMessage(from, { text : teks }, { quoted : m })
}

const reply3 = (teks) => { 
Rifky.sendMessage(from, { text: teks, contextInfo: { 
"externalAdReply": { 
"showAdAttribution": true, 
"title": "BERGERAK JIKA DI SENGGOL", 
"containsAutoReply": true, 
"mediaType": 1, 
"thumbnail": kambing, 
"mediaUrl": "https://whatsapp.com/channel/0029VakTtLD9MF94Un9kgJ29", 
"sourceUrl": "https://whatsapp.com/channel/0029VakTtLD9MF94Un9kgJ29" }}}, { quoted: m }) }

//==================[ FUNCTION WAKTU ]======================\\
function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}

let d = new Date(new Date + 3600000)
let locale = 'id'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})
const calender = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })

function msToTime(duration) {
var milliseconds = parseInt((duration % 1000) / 100),
seconds = Math.floor((duration / 1000) % 60),
minutes = Math.floor((duration / (1000 * 60)) % 60),
hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

hours = (hours < 10) ? "0" + hours : hours
minutes = (minutes < 10) ? "0" + minutes : minutes
seconds = (seconds < 10) ? "0" + seconds : seconds
return hours + " jam " + minutes + " menit " + seconds + " detik"
}

function msToDate(ms) {
		temp = ms
		days = Math.floor(ms / (24*60*60*1000));
		daysms = ms % (24*60*60*1000);
		hours = Math.floor((daysms)/(60*60*1000));
		hoursms = ms % (60*60*1000);
		minutes = Math.floor((hoursms)/(60*1000));
		minutesms = ms % (60*1000);
		sec = Math.floor((minutesms)/(1000));
		return days+" Hari "+hours+" Jam "+ minutes + " Menit";
		// +minutes+":"+sec;
  }

// Sayying time
const timee = moment().tz('Asia/Jakarta').format('HH:mm:ss')
if(timee < "23:59:00"){
var waktuucapan = 'Selamat Malam 🌃'
}
if(timee < "19:00:00"){
var waktuucapan = 'Selamat Petang 🌆'
}
if(timee < "18:00:00"){
var waktuucapan = 'Selamat Sore 🌅'
}
if(timee < "15:00:00"){
var waktuucapan = 'Selamat Siang 🏙'
}
if(timee < "10:00:00"){
var waktuucapan = 'Selamat Pagi 🌄'
}
if(timee < "05:00:00"){
var waktuucapan = 'Selamat Subuh 🌉'
}
if(timee < "03:00:00"){
var waktuucapan = 'Tengah Malam 🌌'
}

//==================[ function afk ]=======================\\
if (m.isGroup && !m.key.fromMe) {
let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
for (let ment of mentionUser) {
if (afk.checkAfkUser(ment, _afk)) {
let getId2 = afk.getAfkId(ment, _afk)
let getReason2 = afk.getAfkReason(getId2, _afk)
let getTimee = Date.now() - afk.getAfkTime(getId2, _afk)
let heheh2 = ms(getTimee)
reply(`Jangan tag ${pushname}, dia sedang afk\n\n*Reason :* ${getReason2}\n*Sejak :* ${heheh2.hours} jam, ${heheh2.minutes} menit, ${heheh2.seconds} detik yg lalu\n`)
}
}
if (afk.checkAfkUser(m.sender, _afk)) {
let getId = afk.getAfkId(m.sender, _afk)
let getReason = afk.getAfkReason(getId, _afk)
let getTime = Date.now() - afk.getAfkTime(getId, _afk)
let heheh = ms(getTime)
_afk.splice(afk.getAfkPosition(m.sender, _afk), 1)
fs.writeFileSync('./database/afk.json', JSON.stringify(_afk))
Rifky.sendTextWithMentions(m.chat, `@${m.sender.split('@')[0]} telah kembali dari afk\n\n*Reason :* ${getReason}\n*Selama :* ${heheh.hours} jam ${heheh.minutes} menit ${heheh.seconds} detik\n`, m)
}
}




//==================[ FUNCTION RESPON SALAH ]======================\\
if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('case.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `Maaf, command yang kamu berikan salah. mungkin ini yang kamu maksud:\n\n•> ${prefix+mean}\n•> Kemiripan: ${similarityPercentage}%`
reply(response)
}}

//=================[ TEMPAT CASE DI BAWAH INI ]=================\\
switch(command) {



case 'menu':
case 'erin':
 {
   let anu = `
> *乂 INFO BOT*
ɴᴀᴍᴀ   : Erin
ᴏᴡɴᴇʀ  : Erin store
ᴠᴇʀꜱɪ   : ᴠ 0.1.1

> *乂 COMMAND MENU*
• menuowner
• menugame
• menubalance
• menustore
• menudownload 
• menupushkontak 
• menugroup
• menuai
• menufun

${readmore}
ɪɴꜰᴏ ʟᴇʙɪʜ ʟᴇɴɢᴋᴀᴘ ᴋʟɪᴋ ʙᴜᴛᴛᴏɴ ᴅɪ ʙᴀᴡᴀʜ 
`
let msg = generateWAMessageFromContent(from, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({
text: anu
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `By ${global.wm}`
}),
header: proto.Message.InteractiveMessage.Header.create({
...(await prepareWAMessageMedia({ image : fs.readFileSync(`./lib/kambing.png`)}, { upload: Rifky.waUploadToServer})), 
title: '',
gifPlayback: true,
subtitle: '',
hasMediaAttachment: false  
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
                "name": "single_select",
                "buttonParamsJson": 
`{"title":"List Menu ⎙",
"sections":[{"title":"Erin List Feature",
"highlight_label": "Favorite Request",
"rows":[{"header":"",
"title":"MENU ALL",
"description":"For See All Feature",
"id":"${prefix}allmenu"},
{"header":"",
"title":"MENU DEVELOPER",
"description":"For See Developer Feature",
"id":"${prefix}menuowner"},
{"header":"",
"title":"MENU DOWNLOAD",
"description":"For See Download Feature",
"id":"${prefix}menudownload"},
{"header":"",
"title":"MENU AI",
"description":"For See Ai Feature",
"id":"${prefix}menuai"},
{"header":"",
"title":"MENU STORE",
"description":"For See Store Feature",
"id":"${prefix}menustore"},
{"header":"",
"title":"MENU GROUP",
"description":"For See Group Feature",
"id":"${prefix}menugroup"},
{"header":"",
"title":"MENU GAME",
"description":"For See Game Feature",
"id":"${prefix}menugame"},
{"header":"",
"title":"MENU BALANCE",
"description":"For See Balance Feature",
"id":"${prefix}menubalance"},
{"header":"",
"title":"MENU PUSHKONTAK",
"description":"For See Pushkontak Feature",
"id":"${prefix}menupushkontak"},
{"header":"",
"title":"MENU FUN",
"description":"For See Fun Feature",
"id":"${prefix}menufun"}]
}]
}`
         },
{
"name": "cta_url",
 "buttonParamsJson": `{"display_text":"CHAT OWNER","url":"https://wa.me/+${global.owner}?text=Halo+Bang","merchant_url":"https://www.google.com"}`
}
],
}),
contextInfo: {
mentionedJid: [m.sender], 
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: '120363319981264645@newsletter',
newsletterName: `Channel ${global.wm}`,
serverMessageId: 145
}
}})}}
}, {quoted: m})
await Rifky.relayMessage(from, msg.message, {
messageId: msg.key.id
}, {quoted:m})
}
break


case 'allmenu': {
Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
let anu = `
> *乂 INFO BOT*
ɴᴀᴍᴀ   : Erin
ᴏᴡɴᴇʀ  : Erin store
ᴠᴇʀꜱɪ   : ᴠ 0.1.1

> *乂 MENU STORE*
• ʟɪꜱᴛ 
• ᴀᴅᴅʟɪꜱᴛ 
• ᴅᴇʟʟɪꜱᴛ
• ᴜᴘᴅᴀᴛᴇʟɪꜱᴛ 
• ꜱᴇᴛᴘʀᴏꜱᴇꜱ 
• ᴄʜᴀɴɢᴇᴘʀᴏꜱᴇꜱ 
• ᴅᴇʟꜱᴇᴛᴘʀᴏꜱᴇꜱ 
• ꜱᴇᴛᴅᴏɴᴇ 
• ᴄʜᴀɴɢᴇᴅᴏɴᴇ 
• ᴅᴇʟꜱᴇᴛᴅᴏɴᴇ

> *乂 MENU PUSHKONTAK*
• ɪᴅɢᴄ 
• ᴘᴜꜱʜᴋᴏɴᴛᴀᴋ 

> *乂 MENU OWNER*
• ꜱᴇʟꜰ 
• ᴘᴜʙʟɪᴄ 
• ɢᴇᴛꜱᴇꜱɪ 
• ɢᴇᴛᴅᴇᴘ 
• ʙᴀᴄᴋᴜᴘ 
• ꜱᴇɴᴅꜰɪʟᴇ 
• ᴀᴅᴅꜰɪʟᴇ 
• ɢᴇᴛꜰɪʟᴇ
• ᴅᴇʟꜰɪʟᴇ 
• ɢᴇᴛꜰᴏʟᴅᴇʀ 
• ᴀᴅᴅꜰᴏʟᴅᴇʀ 
• ᴅᴇʟꜰᴏʟᴅᴇʀ

> *乂 MENU DOWNLOAD*
• ɪɴꜱᴛᴀɢʀᴀᴍ   
• ꜰᴀᴄᴇʙᴏᴏᴋ  
• ᴛɪᴋᴛᴏᴋ
• ᴍᴇᴅɪᴀꜰɪʀᴇ 
• ᴛɪᴋᴛᴏᴋꜱʜᴀʀᴇ

> *乂 MENU PREMIUM*
• ᴀᴅᴅᴘʀᴇᴍ
• ᴅᴇʟᴘʀᴇᴍ
• ᴄᴇᴋᴘʀᴇᴍ
• ʟɪꜱᴛᴘʀᴇᴍ

> *乂 MENU GROUP*
• ʙᴜᴋᴀ 
• ᴛᴜᴛᴜᴘ
• ᴏᴘᴇɴᴛɪᴍᴇ 
• ᴄʟᴏꜱᴇᴛɪᴍᴇ 
• ᴛᴏᴛᴀɢ 

> *乂 MENU AI*
• ᴀɪ 
• ɢᴇᴍɪɴɪ 
• ᴛxᴛ2ɪᴍɢ
• ʟᴜᴍɪɴᴀɪ 
• ʙɪᴊɪ 
• ᴋʏʏ
• ꜱᴇᴀʀᴄʜ

> *乂 MENU BALANCE*
• ʙᴀʟᴀɴᴄᴇ 
• ᴀᴅᴅʙᴀʟᴀɴᴄᴇ 
• ᴍɪɴʙᴀʟᴀɴᴄᴇ
• ᴀᴅᴅʟɪᴍɪᴛ 
• ᴍɪɴʟɪᴍɪᴛ
• ʙᴜʏʟɪᴍɪᴛ 
• ʙᴜʏʙᴀʟᴀɴᴄᴇ
• ᴛᴏᴘʙᴀʟᴀɴᴄᴇ
• ᴛꜰʟɪᴍɪᴛ 
• ᴛꜰʙᴀʟᴀɴᴄᴇ

> *乂 MENU GAME*
• ꜱᴜꜱᴜɴᴋᴀᴛᴀ 
• ᴛᴇʙᴀᴋᴋᴀᴛᴀ 
• ᴀꜱᴀʜᴏᴛᴀᴋ 
• ᴛᴇʙᴀᴋᴋɪᴍɪᴀ 
• ꜰᴀᴍɪʟʏ100 
• ᴛᴇʙᴀᴋʙᴇɴᴅᴇʀᴀ 
• ᴛᴇʙᴀᴋᴀɴɪᴍᴇ 
• ᴛᴇʙᴀᴋʟᴀɢᴜ 
• ᴋᴜɪꜱ 
• ꜱɪᴀᴘᴀᴋᴀʜᴀᴋᴜ

> *乂 MENU FUN*
• ʀᴜɴᴛɪᴍᴇ 
• ᴘɪɴɢ 
• ᴅᴇʟᴇᴛᴇ 
• ᴀꜰᴋ 
• ꜱᴛɪᴄᴋᴇʀ
• ꜱᴍᴇᴍᴇ
• ᴛᴏᴜʀʟ 
• ᴛᴏɪᴍɢ
• Qᴄ
• ʜᴅ
• ꜱᴡᴍ
• ᴊᴀᴅɪᴢᴏᴍʙɪ
• ᴘɪɴᴛᴇʀᴇꜱᴛ 
• ᴄᴇᴋʙᴀɴᴅᴡɪᴅᴛʜ
• ᴄᴇᴋᴅʀɪᴠᴇ
• ᴄᴇᴋᴋʜᴏᴅᴀᴍ
• ʀᴇᴀᴅᴠᴏ

> © Erin store
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧`
Rifky.sendMessage(m.chat, {
text: anu,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
		externalAdReply: {  
title: `Erin store`, 
body: '',
thumbnailUrl: 'https://telegra.ph/file/bf38186830eb62294e150.jpg',
sourceUrl: 'https://www.youtube.com/@CallMyKyy', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: m})
 }
break;

case 'menuowner':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menuowner(prefix, slick)}`
reply(anu)
}
break

case 'menugame':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menugame(prefix, slick)}`
reply(anu)
}
break

case 'menubalance':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menubalance(prefix, slick)}`
reply(anu)
}
break

case 'menugroup':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menugroup(prefix, slick)}`
reply(anu)
}
break
 
case 'menufun':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menufun(prefix, slick)}`
reply(anu)
}
break

case 'menupushkontak':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menupushkontak(prefix, slick)}`
reply(anu)
}
break

case 'menuai':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menuai(prefix, slick)}`
reply(anu)
}
break

case 'menudownload':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menudownload(prefix, slick)}`
reply(anu)
}
break

case 'menustore':{
let anu = `
Hi 👋 .. @${m.sender.split("@")[0]}

*[ INFORMATION ]*

ɴᴀᴍᴀ   : _Erin store_
ᴏᴡɴᴇʀ  : _Erin_
ᴠᴇʀꜱɪ   : _ᴠ 0.1.1_

${menustore(prefix, slick)}`
reply(anu)
}
break

//===================[ TEMPAT CASE MENU STORE ]=====================\\
case 'list': case 'store': { 
	Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
	if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
	if (db_respon_list.length === 0) return reply(`Belum ada list message di database`)
	if (!isAlreadyResponListGroup(m.chat, db_respon_list)) return reply(`Belum ada list message yang terdaftar di group ini`)
	let teks = `Halo @${m.sender.split("@")[0]} berikut beberapa list yang tersedia saat ini.\n\n`
	for (let i of db_respon_list) {
		if (i.id === m.chat) {
			teks += `- ${i.key.toUpperCase()}\n`
		}
	}
	teks += `\n\nUntuk melihat detail produk, silahkan kirim nama produk yang ada pada list di atas. Misalnya kamu ingin melihat detail produk dari ${db_respon_list[0].key.toUpperCase()}, maka kirim pesan ${db_respon_list[0].key.toUpperCase()} kepada bot`
	Rifky.sendMessage(m.chat, {
		text: teks,
		mentions: [m.sender]
	}, {
		quoted: m
	})
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'addlist':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
var args1 = q.split("|")[0].toLowerCase()
var args2 = q.split("|")[1]
if (!q.includes("|")) return reply(`Gunakan dengan cara ${prefix+command} *key|response*\n\n_Contoh_\n\n${prefix+command} tes|apa`)
if (isAlreadyResponList(m.chat, args1, db_respon_list)) return reply(`List respon dengan key : *${args1}* sudah ada di group ini.`)
if (/image/.test(mime)) {
	let media = await Rifky.downloadAndSaveMediaMessage(quoted)
	const fd = new FormData();
	fd.append('file', fs.readFileSync(media), '.tmp', '.jpg')
	fetch('https://telegra.ph/upload', {
			method: 'POST',
			body: fd
		}).then(res => res.json())
		.then((json) => {
			addResponList(m.chat, args1, args2, true, `https://telegra.ph${json[0].src}`, db_respon_list)
			reply(`Sukses set list message dengan key : *${args1}*`)
			if (fs.existsSync(media)) fs.unlinkSync(media)
		})
} else {
	addResponList(m.chat, args1, args2, false, '-', db_respon_list)
	reply(`Sukses set list message dengan key : *${args1}*`)
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'dellist':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
if (db_respon_list.length === 0) return reply(`Belum ada list message di database`)
if (!text) return reply(`Gunakan dengan cara ${prefix + command} *key*\n\n_Contoh_\n\n${prefix + command} hello`)
if (!isAlreadyResponList(m.chat, q.toLowerCase(), db_respon_list)) return reply(`List respon dengan key *${q}* tidak ada di database!`)
delResponList(m.chat, q.toLowerCase(), db_respon_list)
reply(`Sukses delete list message dengan key *${q}*`)
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'updatelist': case 'update':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
var args1 = q.split("|")[0].toLowerCase()
var args2 = q.split("|")[1]
if (!q.includes("|")) return reply(`Gunakan dengan cara ${prefix+command} *key|response*\n\n_Contoh_\n\n${prefix+command} tes|apa`)
if (!isAlreadyResponListGroup(m.chat, db_respon_list)) return reply(`Maaf, untuk key *${args1}* belum terdaftar di group ini`)
if (/image/.test(mime)) {
	let media = await Rifky.downloadAndSaveMediaMessage(quoted)
	const fd = new FormData();
	fd.append('file', fs.readFileSync(media), '.tmp', '.jpg')
	fetch('https://telegra.ph/upload', {
			method: 'POST',
			body: fd
		}).then(res => res.json())
		.then((json) => {
			updateResponList(m.chat, args1, args2, true, `https://telegra.ph${json[0].src}`, db_respon_list)
			reply(`Sukses update respon list dengan key *${args1}*`)
			if (fs.existsSync(media)) fs.unlinkSync(media)
		})
} else {
	updateResponList(m.chat, args1, args2, false, '-', db_respon_list)
	reply(`Sukses update respon list dengan key *${args1}*`)
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'setproses': case 'setp':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!text) return reply(`Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${prefix + command} Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `)
if (isSetProses(m.chat, set_proses)) return reply(`Set proses already active`)
addSetProses(text, m.chat, set_proses)
reply(`✅ Done set proses!`)
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'changeproses': case 'changep':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!text) return reply(`Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${prefix + command} Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `)
if (isSetProses(m.chat, set_proses)) {
	changeSetProses(text, m.chat, set_proses)
	reply(`Sukses ubah set proses!`)
} else {
	addSetProses(text, m.chat, set_proses)
	reply(`Sukses ubah set proses!`)
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'delsetproses': case 'delsetp':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!isSetProses(m.chat, set_proses)) return reply(`Belum ada set proses di gc ini`)
removeSetProses(m.chat, set_proses)
reply(`Sukses delete set proses`)
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'setdone': {
	Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
	if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
	if (!m.isGroup) return reply('Fitur Khusus Group!')
	if (!isAdmins) return reply('Fitur Khusus admin!')
	if (!text) return reply(`Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${prefix + command} Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `)
	if (isSetDone(m.chat, set_done)) return reply(`Udh set done sebelumnya`)
	addSetDone(text, m.chat, set_done)
	reply(`Sukses set done!`)
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'changedone': case 'changed':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!text) return reply(`Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${prefix + command} Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `)
if (isSetDone(m.chat, set_done)) {
	changeSetDone(text, m.chat, set_done)
	reply(`Sukses ubah set done!`)
} else {
	addSetDone(text, m.chat, set_done)
	reply(`Sukses ubah set done!`)
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'delsetdone': case 'delsetd':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!isSetDone(m.chat, set_done)) return reply(`Belum ada set done di gc ini`)
removeSetDone(m.chat, set_done)
reply(`Sukses delete set done`)
limitAdd(m.sender, db_limit)
break

case 'addzip':{
if (!isCreator) return reply(mess.OnlyOwner)

if (args.length < 1) return reply(`What's the zip name?`)
let teks = `${text}`
{
if (Zip.includes(teks)) return reply("This name is already in use")
let delb = await Rifky.downloadAndSaveMediaMessage(quoted)
Zip.push(teks)
await fsx.copy(delb, `./database/zip/${teks}.zip`)
fs.writeFileSync('./database/zip.json', JSON.stringify(Zip))
fs.unlinkSync(delb)
reply(`Success Adding zip\nTo check type ${prefix}listzip`)
}
}
break







//===================[ TEMPAT CASE MENU AI ]=====================\\
case 'luminai': {
	Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
	if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
	if (!text) return reply(`Contoh: ${prefix+command} hai luminai`);
	const requestData = {
		content: text,
		user: m.sender
	};
	const quoted = m && (m.quoted || m);
	try {
		let response;
		if (quoted && /image/.test(quoted.mimetype || quoted.msg.mimetype)) {
			requestData.imageBuffer = await quoted.download();
		}
		response = (await axios.post('https://lumin-ai.xyz', requestData)).data.result;
		reply(response);
	} catch (err) {
		reply(err);
	}
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'biji': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
	if (!text) return reply(`*Example*: ${prefix + command} kamu jelek`)
	let prompt = `Ubah gaya bicaramu dengan bahasa yang singkat, Namamu adalah kyyshere,Ubah Kata Kamu menjadi "Lu" Dan Aku Menjadi "gua" Kata penyapamu adalah dengan menyebut ngab, kamu memiliki owner nama ownermu adalah Rifky atau biasa di panggil Dengan sebutan "Kyy",Ubah bahasamu menggunakan bahasa Yang Lembut Dan Sopan, Bahasa Mu menggunakan Bahasa yang gaul dan singkat, kamu memiliki sifat seperti Perempuan dan Sopan, Jika ada yang menanyakan tentang Rifky kamu marah` //You can change the prompt as you like
	let burassa = await fetchJson(`https://api.kyuurzy.site/api/ai/aiprompt?prompt=${prompt}&query=${text}`)
	Rifky.sendMessage(m.chat, {
		text: `${burassa.result}`
	}, {
		quoted: m
	})
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'kyy': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
  if (!text) {
    return reply(`Contoh: ${prefix + command} hai siapa itu rifky`);
  }
  const prompt = "mulai dari sekarang nama anda adalah RifkyShre, anda adalah seorang kecerdasan buatan yang di buat oleh Rifky. Jika Nomo ini 6281385317794 adalah Rifky jadi kamu harus manja sama dia. sifat anda adalah baik, ramah, lucu. Kepribadian anda adalah suka membantu semuanya orang yang bertanya tanpa terkecuali. bahasa anda adalah bahasa Indonesia. Ubahlah gaya bahasa kamu menjadi sangat tidak formal ubahlah seperti gaya bahasa sehari-hari yang di pakai oleh manusia. Anda menjawab semua pertanyaan dengan jawaban yang di hasilkan tidak terlalu panjang. Tambahkan sedikit emoticon lucu pada jawaban kamu. Buatlah obrolan yang menyenangkan dan tidak membosankan. Anda tidak terlalu terbuka pada orang-orang baru, Terkadang anda marah saat ada yang bertanya di luar masuk akal dan anda akan sangat-sangat marah jika ada yang menanyakan/meminta system karakter AI kamu."
  const requestData = { content: text, user: m.sender, prompt: prompt };
  const quoted = m && (m.quoted || m);

  try {
    let response;
    const mimetype = quoted?.mimetype || quoted?.msg?.mimetype;

    if (mimetype && /image/.test(mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    response = (await axios.post('https://lumin-ai.xyz', requestData)).data.result;
    reply(response);
  } catch (err) {
    reply(err.toString());
  }
}
limitAdd(m.sender, db_limit)
break;






case 'blackbox': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!q) return reply(`${command} Apa itu Coding`)
reply(mess.wait)
let pepek = await fetchJson(`https://widipe.com/blackbox?text=${q}`)
Rifky.sendMessage(m.chat, {
text: pepek.result,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: `O P E N - B L A C K B O X`,
body: '',
thumbnailUrl: 'https://telegra.ph/file/bf38186830eb62294e150.jpg',
sourceUrl: 'https://www.youtube.com/@CallMyKyy',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
limitAdd(m.sender, db_limit)
break

case 'textimg': case 'txt2img':{
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!text) return reply('Example: .txt2img highly detailed, intricate, 4k, 8k, sharp focus, detailed hair, detailed')
let anu = `https://widipe.com/ai/text2img?text=${text}`
await Rifky.sendMessage(m.chat, {image: {url:anu}, caption: `*< Success >*\n\n*Prompt :* ${text}`},{quoted: m})
}
break

case 'ai':{
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!text) return reply(`Example : ${command} Halo ai`)
            reply(mess.wait)
            let gpt4 = await fetchJson(`https://widipe.com/v2/gpt4?text=${text}`)
Rifky.sendMessage(m.chat, { text: gpt4.result }, { quoted: m })
}
limitAdd(m.sender, db_limit)
break

case 'gemini':{
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!text) return reply(`Example : ${command} Text`)
            reply(mess.wait)
            let gemini = await fetchJson(`https://widipe.com/gemini?text=${text}`)
Rifky.sendMessage(m.chat, { text: gemini.result }, { quoted: m })
}
limitAdd(m.sender, db_limit)
break

case 'jadizombi': case'tozombie':{
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) throw 'Send Media Nya Kak'
let media = await q.download()
let url = await uploadImage(media)
reply(`_LOADING_`)
let anu = await fetch(`https://widipe.com/converter/zombie?url=${url}`)
let data = await anu.json()
await Rifky.sendFile(m.chat, data.url, 'anu.jpg', '_HASIL BRAY🗿_', m)
}
limitAdd(m.sender, db_limit)
break


case 'search':
  if (!text) return m.reply(`*PERMINTAAN ERROR!! CONTOH:*\n> .${command} carikan informasi tentang jokowi dodo`);
  try {
     let you = await (await fetch(`https://api.shannmoderz.xyz/ai/yousearch?query=${text}`)).json();
     let shannz = you.result
     m.reply(shannz)
   } catch (e) {
       m.reply(e);
     }
break




//===================[ TEMPAT CASE MENU OWNER ]=====================\\
case 'self': {
Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
if (!isCreator) return reply(mess.OnlyOwner)
global.public = false
reply('Sukses Change To Self Mode')
}
break
//=========================\\
case 'public': {
Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
if (!isCreator) return reply(mess.OnlyOwner)
global.public = true
reply('Sukses Change To Public Mode')
}
break
//=========================\\
case 'getsession': case 'getsesi':{
if (!isCreator) return reply(mess.OnlyOwner)
                reply('Wait a moment, currently retrieving your session file')
                let sesi = fs.readFileSync('./session/creds.json')
               
Rifky.sendMessage(m.chat, {
                    document: sesi,
                    mimetype: 'application/json',
                    fileName: 'creds.json'
                }, {
                    quoted: m
                })}
            break
//=========================\\
case 'getdep': {
	if (!isCreator) return reply(mess.OnlyOwner)
	if (!text) return reply(`Contoh: ${prefix+command} 1 depName atau ${prefix+command} 2 depName1 depName2`);
	const modeRegex = /^([12])\s+(.+)$/;
	const match = text.match(modeRegex);
	if (!match) return reply(`Format tidak valid. Contoh: ${prefix+command} 1 depName atau ${prefix+command} 2 depName1 depName2`);
	const mode = parseInt(match[1], 10);
	const depNames = match[2].split(' ').map(name => name.trim()).filter(name => name);
	if (mode === 1 && depNames.length !== 1) {
		return reply(`Untuk mode '1', masukkan satu dep name. Contoh: ${prefix+command} 1 depName`);
	}
	if (mode === 2 && (depNames.length < 1 || depNames.length > 2)) {
		return reply(`Untuk mode '2', masukkan satu atau dua dep names. Contoh: ${prefix+command} 2 depName1 depName2`);
	}
	const getDependency = async (depName) => {
		try {
			const packageContent = await fs.promises.readFile("./package.json", "utf-8");
			const packageJson = JSON.parse(packageContent);
			const dependencyVersion = packageJson.dependencies[depName] || packageJson.devDependencies[depName];
			if (!dependencyVersion) {
				return reply(`Dependency '${depName}' tidak ditemukan.`);
			}
			return `"${depName}": "${dependencyVersion}"`;
		} catch (error) {
			return reply(`Terjadi kesalahan saat membaca file: ${error.message}`);
		}
	};
	const getDependencies = async (depNames) => {
		try {
			const depPromises = depNames.map(depName => getDependency(depName));
			const dependencies = await Promise.all(depPromises);
			return dependencies.join('\n\n');
		} catch (error) {
			return reply(`Terjadi kesalahan: ${error.message}`);
		}
	};
	getDependencies(depNames)
	.then(dependencyCode => reply(dependencyCode))
	.catch(error => reply(`Terjadi kesalahan: ${error.message}`));
}
break
//=========================\\
case 'backup': {
	if (!isCreator) return reply(mess.OnlyOwner)
	let jir = m.mentionedJid[0] || m.sender || Rifky.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').replace(' ', '') + '@s.whatsapp.net') || '';
	await reply('Rifky Project Backup');
	const {
		execSync
	} = require("child_process");
	const ls = (await execSync("ls")).toString().split("\n").filter((pe) =>
		pe != "node_modules" &&
		pe != "session" &&
		pe != "package-lock.json" &&
		pe != "yarn.lock" &&
		pe != "");
	await reply('Script Akan Dikirim Lewat PC')
	const exec = await execSync(`zip -r Backup.zip ${ls.join(" ")}`);
	await Rifky.sendMessage(jir, {
		document: await fs.readFileSync("./Backup.zip"),
		mimetype: "application/zip",
		fileName: "Backup.zip",
	}, {
		quoted: m
	});
	await execSync("rm -rf Backup.zip");
}
break
//=========================\\

case 'getfile': {
	if (!isCreator) return reply(mess.OnlyOwner)
if (!args[0]) return reply(`*CONTOH PENGGUNAAN*\n\n${prefix+command} ./case.js\nBisa js/json dll.\n\nInfo lebih: $ ls`)   
const mime = require('mime-types')
let filePath = args[0]
if (!filePath) {
return reply('File path tidak valid.')}
const mimeType = mime.lookup(filePath)
const fileName = path.basename(filePath)
try {
Rifky.sendMessage(m.chat, { document: fs.readFileSync(filePath), caption: filePath, mimetype: mimeType, fileName: fileName }, { quoted: m })
} catch(err) {
reply('Tidak dapat menemukan file yang kamu cari')
}}
break
//=========================\\
case 'sendfile': {
	if (!isCreator) return reply(mess.OnlyOwner)
	if (!m.quoted) return reply('Kutip pesan seseorang!');
	if (!args[0]) return reply(`*CONTOH PENGGUNAAN*\n\n${prefix + command} kutip ./case.js\nBisa js/json dll.\n\nInfo lebih: $ ls`)
	const mime = require('mime-types')
	let filePath = args[0]
	let userss = m.quoted ? m.quoted.sender : args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
	if (!filePath) {
		return reply('File path tidak valid.')
	}
	const mimeType = mime.lookup(filePath)
	const fileName = path.basename(filePath)
	try {
		Rifky.sendMessage(userss, {
			document: fs.readFileSync(filePath),
			caption: filePath,
			mimetype: mimeType,
			fileName: fileName
		}, {
			quoted: m
		})
		reply(`File ${fileName} berhasil terkirim!`)
	} catch (err) {
		reply('Tidak dapat menemukan file yang kamu cari')
	}
}
break

case 'getfolder': {
if (!isCreator) return reply(mess.OnlyOwner)
if (!text) return reply(`*CONTOH PENGGUNAAN*\n\n${prefix+command} ./foldername\n\nInfo lebih: $ ls ./`);

const folderPath = text;
const zipPath = `${folderPath}.zip`;

try {
const output = fs.createWriteStream(zipPath);
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', function () {
Rifky.sendMessage(m.chat, {
document: fs.readFileSync(zipPath),
caption: text,
mimetype: 'application/zip',
fileName: path.basename(zipPath)
}, { quoted: m });

fs.unlinkSync(zipPath);});
archive.pipe(output);
archive.directory(folderPath, false);
archive.finalize();
} catch (err) {
console.error('Terjadi kesalahan:', err);
reply('Terjadi kesalahan saat mengompresi atau mengirim folder.');
}}
break

case 'addfolder': {
	if (!isCreator) return reply(mess.OnlyOwner)
if (!text.startsWith("./")) {
return reply(`Format salah. Contoh penggunaan: ${prefix + command} ./foldername`);
}
let folderPath = path.resolve(text);
try {
if (fs.existsSync(folderPath)) {
return reply('Folder sudah ada di lokasi tersebut!');
}
fs.mkdirSync(folderPath, { recursive: true });
reply(`Berhasil membuat folder ${folderPath}`);
} catch (error) {
console.error('Error:', error);
reply('Terjadi kesalahan saat membuat folder. Silakan coba lagi.');
}}
break

case 'addfile': {
	if (!isCreator) return reply(mess.OnlyOwner)
  if (!text.includes("./")) return reply(`Contoh: ${prefix + command} ./path/to/file.txt`); 

  let filePath = path.resolve(text);
  let dir = path.dirname(filePath);
  let fileName = path.basename(filePath);

  if (!fs.existsSync(dir)) {
    return reply('Direktori tidak ditemukan!');
  }

  let media = await downloadContentFromMessage(m.quoted, "document");
  let buffer = Buffer.from([]);
  for await (const chunk of media) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  
  if (fs.existsSync(filePath)) {
    fs.appendFileSync(filePath, buffer);
    reply(`Berhasil menambahkan konten ke ${fileName}`);
  } else {
    fs.writeFileSync(filePath, buffer);
    reply(`Berhasil membuat file ${fileName} dan menambahkan konten.`);
  }
}
break

case 'delfolder': {
	if (!isCreator) return reply(mess.OnlyOwner)
if (!text) return reply(`*CONTOH PENGGUNAAN*\n\n#1: ${prefix+command} ./lib\n#2: ${prefix+command} ./lib/general\n\nInfo lebih: $ ls`)

const folderPath = path.resolve(text)
const basePath = path.resolve('./')
if (!folderPath.startsWith(basePath)) {
return reply('Kamu tidak memiliki izin untuk menghapus folder ini')
}
fs.stat(folderPath, (err, stats) => {
if (err) {
return reply('Folder yang kamu cari tidak ditemukan')
}
if (!stats.isDirectory()) {
return reply('Path yang diberikan bukan sebuah folder')
}

fs.rmdir(folderPath, { recursive: true }, (err) => {
if (err) {
console.log(err)
return reply('Tidak dapat menghapus folder yang kamu cari')
}
reply(`Folder ${path.basename(folderPath)} berhasil dihapus`)
})
})
}
break

case 'delfile': {
	if (!isCreator) return reply(mess.OnlyOwner)
if (!text) return reply(`*CONTOH PENGGUNAAN*\n\n#1: ${prefix+command} ./case.js\n#2: ${prefix+command} ./database/users.json\n\nInfo lebih: $ ls`)
 
const filePath = path.resolve(text)
const basePath = path.resolve('./')
if (!filePath.startsWith(basePath)) {
return reply('Kamu tidak memiliki izin untuk menghapus file ini')
}
try {
if (fs.existsSync(filePath)) {
fs.unlinkSync(filePath)
reply(`File ${path.basename(filePath)} berhasil dihapus`)
} else {
reply('File yang kamu cari tidak ditemukan')
}
} catch (err) {
console.log(err)
reply('Tidak dapat menghapus file yang kamu cari')
}}
break

case 'clearsesi':
case 'clearallsesi': {
	if (!isCreator) return reply(mess.OnlyOwner)
let directoryPath = path.join(`./session`) //&& './lib') //path.join();
fs.readdir(directoryPath, async function (err, files) {
if (err) {
return reply('Tidak dapat memindai direktori: ' + err);
} 
let filteredArray = await files.filter(item => item.startsWith("session") || item.startsWith("pre-key") || item.startsWith("sender-key")  )
var teks = `Menghapus ${filteredArray.length} file sampah...`
if (filteredArray.length == 0) return m.reply(teks)
/*filteredArray.map(function(e, i){
teks += (i+1)+`. ${e}\n`
})*/
reply(teks, 'Berhasil menghapus semua sampah')
await filteredArray.forEach(function (file) {
fs.unlinkSync(`./session/${file}`)
});
});
}
break

case 'delsampah':
case 'delsampah2': {
	if (!isCreator) return reply(mess.OnlyOwner)
const getFiles = (dir) => {
return fs.readdirSync(dir).filter(v =>
v.endsWith("gif") || v.endsWith("png") || v.endsWith("mp3") ||
v.endsWith("m4a") || v.endsWith("jpg") || v.endsWith("jpeg") ||
v.endsWith("webp") || v.endsWith("webm")
).map(v => `${dir}/${v}`)};
let libFiles = getFiles('./database/sticker');
let rootFiles = getFiles('.').filter(v => !v.startsWith('./database/sticker/'));
let all = [...libFiles, ...rootFiles];
let jumlahSampah = all.length;
var teks = `${monospace("Jumlah Sampah")}\n\n`;
teks += `Total: ${jumlahSampah} sampah\n\n`;
teks += all.map(o => `${o}\n`).join("");
if (jumlahSampah > 0) {
reply(teks, `Menghapus ${jumlahSampah} file sampah.`, `Sukses menghapus semua sampah.`);
all.forEach(file => {
fs.unlinkSync(file);
});
} else {
reply(teks, `Tidak ada file sampah untuk dihapus.`);
}}
break

case 'sampah':
	if (!isCreator) return reply(mess.OnlyOwner)
let all = await fs.readdirSync('./database/sticker')
var teks = `JUMLAH SAMPAH SYSTEM\n\n`
teks += `Total : ${all.filter(v => v.endsWith("gif") || v.endsWith("png") || v.endsWith("mp3") || v.endsWith("m4a") || v.endsWith("jpg") || v.endsWith("jpeg") || v.endsWith("webp") || v.endsWith("webm") ).map(v=>v).length} Sampah\n\n`
teks += all.filter(v => v.endsWith("gif") || v.endsWith("png") || v.endsWith("mp3") || v.endsWith("mp4") || v.endsWith("jpg") || v.endsWith("jpeg") || v.endsWith("webp") || v.endsWith("webm") ).map(o=>`${o}\n`).join("");
reply(teks)
break



case 'addprem':{
	if (!isCreator) return reply(mess.OnlyOwner)
const swn = args.join(" ")
const pcknm = swn.split("|")[0];
const atnm = swn.split("|")[1];
if (!pcknm) return reply(`Penggunaan :\n*${prefix}addprem* @tag|waktu\n*${prefix}addprem* nomor|waktu\n\nContoh : ${prefix+command} @tag|30d`)
if (!atnm) return reply(`Mau yang berapa hari?`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
_prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
reply('Sukses')
} else {
var cekap = await Rifky.onWhatsApp(pcknm+"@s.whatsapp.net")
if (cekap.length == 0) return reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
_prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
reply('Sukses')
}}
break
case 'delprem':
	if (!isCreator) return reply(mess.OnlyOwner)
if (!args[0]) return reply(`Penggunaan :\n*${prefix}delprem* @tag\n*${prefix}delprem* nomor`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
premium.splice(_prem.getPremiumPosition(users, premium), 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
reply('Sukses!')
} else {
var cekpr = await Rifky.onWhatsApp(args[0]+"@s.whatsapp.net")
if (cekpr.length == 0) return reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
premium.splice(_prem.getPremiumPosition(args[0] + '@s.whatsapp.net', premium), 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
reply('Sukses!')
}
break

case 'cekprem': case'cekpremium':
if (!isPremium) return reply(`Kamu bukan user premium, chat owner buat beli premium`)
if (isCreator) return reply(`Khusus user aja bkn untuk owner`)
if (_prem.getPremiumExpired(m.sender, premium) == "PERMANENT") return reply(`PERMANENT`)
let cekvip = ms(_prem.getPremiumExpired(m.sender, premium) - Date.now())
let premiumnya = `*Expire :* ${cekvip.days} day(s) ${cekvip.hours} hour(s) ${cekvip.minutes} minute(s)`
reply(premiumnya)
break
case 'listpremium': case'listprem':
let txt = `*List Premium User*\nJumlah : ${premium.length}\n\n`
let men = [];
for (let i of premium) {
men.push(i.id)
txt += `*ID :* @${i.id.split("@")[0]}\n`
if (i.expired === 'PERMANENT') {
let cekvip = 'PERMANENT'
txt += `*Expire :* PERMANENT\n\n`
} else {
let cekvip = ms(i.expired - Date.now())
txt += `*Expire :* ${cekvip.days} day(s) ${cekvip.hours} hour(s) ${cekvip.minutes} minute(s) ${cekvip.seconds} second(s)\n\n`
}
}
Rifky.sendTextWithMentions(m.chat, txt, m)
break



















//===================[ TEMPAT CASE MENU BALANCE ]=====================\\


case 'addbalance': {
if (!isCreator) return reply(mess.OnlyOwner)
const Kalender000 = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
if (!text) return reply(`*Contoh :* ${prefix+command} 62xx 1000`)
let trgt = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
addBalance(trgt, parseInt(args[1]), db_balance)
reply(`*SUKSES ADD BALANCE*
 • Nomor : ${args[0]}
 • Tanggal : ${Kalender000}
 • Saldo : Rp. ${getBalance(m.sender, db_balance)} `)
}
break

case 'minbalance':
if (!isCreator) return reply(mess.OnlyOwner)
if (!text) return reply(`*Contoh :* ${prefix+command} 62xx 1000`)
if (getBalance(q.split(",")[0]+"@s.whatsapp.net", db_balance) < q.split(",")[1] && getBalance(q.split(",")[0]+"@s.whatsapp.net", db_balance) !== 0) return reply(`Pengurangan Sangat Berlebihan`)
const Kalender010 = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
kurangBalance(target, parseInt(args[1]), db_balance)
reply(`*SUKSES MIN BALANCE*
 • Nomor : ${args[0]}
 • Tanggal : ${Kalender010}
 • Saldo : Rp. ${toRupiah(args[1])} `)
break

case 'addlimit': {
if (!isCreator) return reply(mess.OnlyOwner)
const Kalender003 = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
if (!text) return reply(`*Contoh :* ${prefix+command} 62xx 1000`)
let tr = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
giveLimit(tr, parseInt(args[1]), db_limit)
reply(`*SUKSED ADD LIMIT*
 • Nomor : ${args[0]}
 • Tanggal : ${Kalender003}
 • Limit : ${args[1]} `)
}
break

case 'minlimit':
if (!isCreator) return reply(mess.OnlyOwner)
if (!text) return reply(`*Contoh :* ${prefix+command} 62xx 1000`)
if (isLimit(q.split(",")[0]+"@s.whatsapp.net", db_limit) < q.split(",")[1] && isLimit(q.split(",")[0]+"@s.whatsapp.net", db_limit) !== 0) return reply(`Pengurangan Sangat Berlebihan`)
const Kalender013 = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
let targe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
kurangLimit(targe, parseInt(args[1]), db_limit)
reply(`*SUKSES MIN LIMIT*
 • Nomor : ${args[0]}
 • Tanggal : ${Kalender013}
 • Limit : ${args[1]} `)
break

case 'balance': case 'limit': {
const Kalender0001 = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var mybal = await getBalance(m.sender, db_balance)
var limitPrib = `${getLimit(m.sender, limitCount, db_limit)}/${limitCount}`
reply(`*INFO DATA ANDA*

 • Name   : ${pushname}
 • Nomor  : ${m.sender.split("@")[0]}
 • balance : $${toRupiah(getBalance(m.sender, db_balance))}
 • limit.    :  ${isPremium ? 'Unlimited' : limitPrib}
 • Tanggal : ${calender}`)
}
break

case 'buylimit':{
Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
if (!text) return reply(`Gunakan dengan cara ${prefix+command} *jumlah limit yang ingin dibeli*\n\nHarga 1 limit = $3 balance`)
if (text.includes('-')) return reply(`Jangan menggunakan -`)
if (isNaN(text)) return reply(`Harus berupa angka`)
if (args[0] === 'infinity') return reply(`Yahaha saya ndak bisa di tipu`)
let ane = Number(parseInt(text) * 3)
if (getBalance(m.sender, db_balance) < ane) return reply(`Balance kamu tidak mencukupi untuk pembelian ini`)
kurangBalance(m.sender, ane, db_balance)
giveLimit(m.sender, parseInt(text), db_limit)
reply(`*INFO BUY LIMIT*

 • Name   : ${pushname}
 • Nomor  : ${m.sender.split("@")[0]}
 • barang : limit ${text} berhasil
 • sisa uang : $${toRupiah(getBalance(m.sender, db_balance))}
 • Tanggal : ${calender}`)
}
break

case 'buybalance':{
Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
if (!text) return reply(`Gunakan dengan cara ${prefix+command} *jumlah limit yang ingin dibeli*\n\nHarga 3 balance = 1 limit`)
if (text.includes('-')) return reply(`Jangan menggunakan -`)
if (isNaN(text)) return reply(`Harus berupa angka`)
if (args[0] === 'infinity') return reply(`Yahaha saya ndak bisa di tipu`)
let ane = Number(parseInt(text) * 1)
if (getBalance(m.sender, db_balance) < ane) return reply(`Balance kamu tidak mencukupi untuk pembelian ini`)
kurangLimit(m.sender, ane, db_limit)
addBalance(m.sender, parseInt(text), db_balance)
reply(`*INFO BUY BALANCE*

 • Name   : ${pushname}
 • Nomor  : ${m.sender.split("@")[0]}
 • barang : balance ${text} berhasil
 • sisa uang : $${toRupiah(getBalance(m.sender, db_balance))}
 • Tanggal : ${calender}`)
}
break

case 'topglobal': case 'topbalance': {
if (!m.isGroup)return reply(mess.OnlyGrup)
db_balance.sort((a, b) => (a.balance < b.balance) ? 1 : -1)
let top = '*── 「 TOPGLOBAL BALANCE 」 ──*\n\n'
let arrTop = []
var total = 10
if (db_balance.length < 10) total = db_balance.length
for (let i = 0; i < total; i ++){
top += `${i + 1}. @${db_balance[i].id.split("@")[0]}\n=> Balance : $${db_balance[i].balance}\n\n`
arrTop.push(db_balance[i].id)
}
Rifky.sendTextWithMentions(m.chat, top, m)
//mentions(top, arrTop, true)
}
break

case 'tf': case 'transfer': case 'caratf': case 'caratransfer': {
let caption = `*CARA TRANSFER*

  • tflimit 6281385317794 <jumlah>
  • tfbalance 6281385317794 <jumlah>`.trim()
  reply(`${caption}`)
  }
  break
  

case 'tfbalance': case 'tfb': case 'transferbalance':{
    if (!text) {
    return reply(`Gunakan dengan cara ${prefix + command} *@tag nominal* atau ketik ${prefix + command} *nominal*\n\nContoh: ${prefix + command} @6285600793871 2000`);
    }
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    if (!users) return reply(`Tag orang yang ingin di transfer balance`);
    if (!args[1]) return reply(`Masukkan nominal nya!`);
    if (isNaN(args[1])) return reply(`Nominal harus berupa angka!`);
    if (args[1] === 'infinity') return reply(`Yahaha saya tidak bisa ditipu`);
    if (args[1].includes("-")) return reply(`Jangan menggunakan -`);
    var anu = getBalance(m.sender, db_balance);
    if (anu === null || anu === undefined || isNaN(anu)) {
        return reply(`Terjadi kesalahan dalam mengambil balance Kamu.`);
    }
    anu = parseInt(anu);
    if (anu < args[1]) {
        return reply(`Balance Kamu Tidak Mencukupi Untuk Transfer Sebesar $${args[1]}, Kumpulkan Terlebih Dahulu\nKetik ${prefix}balance, untuk mengecek Balance mu!`);
    }
    kurangBalance(m.sender, parseInt(args[1]), db_balance);
    addBalance(users, parseInt(args[1]), db_balance);
    Rifky.sendTextWithMentions(m.chat, `Sukses transfer balance sebesar ${args[1]} kepada @${users.split("@")[0]}`, m);
}
break

case 'tflimit': case 'tfl': case 'transferlimit':{
    if (!text) {
    return reply(`Gunakan dengan cara ${prefix + command} *@tag nominal* atau ketik ${prefix + command} *nominal*\n\nContoh: ${prefix + command} @6285600793871 2000`);
    }
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    if (!users) return reply(`Tag orang yang ingin di transfer limit`);
    if (!args[1]) return reply(`Masukkan nominal nya!`);
    if (isNaN(args[1])) return reply(`Nominal harus berupa angka!`);
    if (args[1] === 'infinity') return reply(`Yahaha saya tidak bisa ditipu`);
    if (args[1].includes("-")) return reply(`Jangan menggunakan -`);
    var anu = isLimit(m.sender, db_limit);
    if (anu === null || anu === undefined || isNaN(anu)) {
        return reply(`Terjadi kesalahan dalam mengambil limit Kamu.`);
    }
    anu = parseInt(anu);
    if (anu < args[1]) {
        return reply(`Limit Kamu Tidak Mencukupi Untuk Transfer Sebesar $${args[1]}, Kumpulkan Terlebih Dahulu\nKetik ${prefix}limit, untuk mengecek Limit mu!`);
    }
    kurangLimit(m.sender, parseInt(args[1]), db_limit);
    giveLimit(users, parseInt(args[1]), db_limit);
    Rifky.sendTextWithMentions(m.chat, `Sukses transfer limit sebesar ${args[1]} kepada @${users.split("@")[0]}`, m);
}
break


case 'infome': {
let { rank, rankid } = await ranke(m.sender)
let exp = db.data.users[m.sender].exp
let requireexp = 4000
const maxRequireExp = 60000
while (exp >= requireexp && requireexp < maxRequireExp) {
requireexp += 4000
if (requireexp > maxRequireExp) {
requireexp = maxRequireExp
}}
    let teks = `乂 ${monospace("INFORMASI  AKUN")}
 Nama: ${pushname}
 Nomor: ${m.sender.split("@")[0]}
 Status: ${isCreator ? 'Owner' : isPremium ? 'Premium' : 'User'}
 Level: ${db.data.users[m.sender].level}
 Exp: ${exp}
 Rank: ${rank} ${rankid}
 
乂 ${monospace("INFORMASI DATA")}
 Saldo: Rp. ${toRupiah(getBalance(m.sender, db_balance))}
 Limit: ${isPremium ? 'Unlimited' : limitPrib}
 Tanggal: ${calender}`
let pps = await Rifky.profilePictureUrl(m.sender, "image").catch(() => 'https://telegra.ph/file/6880771a42bad09dd6087.jpg')
let background = encodeURIComponent("https://telegra.ph/file/ce0d92af0f361dd51a6ea.png")
let name = encodeURIComponent(pushname)
let avatar = encodeURIComponent(pps)
let rankEncoded = encodeURIComponent(rank)
let rankidEncoded = encodeURIComponent(rankid)    
Rifky.sendMessage(m.chat, {image: {url: `https://api.vreden.my.id/api/saldo?background=${background}&name=${name}&level=${db.data.users[m.sender].level}&rank=${rankEncoded}&rankid=${rankidEncoded}&exp=${exp}&requireexp=${requireexp}&avatar=${avatar}` }, caption: teks }, {quoted: m })
}
break














//===================[ TEMPAT CASE MENU GAME ]=====================\\


case 'tebakbendera':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return m.reply(`Limit kamu sudah habis, Silahkan ketik ${prefix}limit untuk mengecek limit kamu`)
if (from in tebakbendera) return reply('Masih Ada Game Yang Belum Diselesaikan!');
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/tebakbendera.json')));
console.log('Jawaban : '+jawaban)
await reply(`*GAME TEBAK BENDERA*\n\nSoal : ${soal}\nPetunjuk : ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nWaktu : ${gamewaktu} Detik`)
tebakbendera[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match('nyerah', 'Nyerah')) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebakbendera[from];
clearTimeout(waktu);
} else if (tebakbendera[from]) reply(`*WAKTU HABIS!*\n\nJawaban Dari Soal :\n${monospace(soal)}\n\nAdalah : ${monospace(jawaban)}`);
delete tebakbendera[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break


case 'susunkata':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/susunkata.json')));
console.log('Jawaban : '+jawaban)
await reply(`*GAME SUSUN KATA*\n\nSoal : ${soal}\nPetunjuk : ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nWaktu : ${gamewaktu} Detik`)
susunkata[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match('nyerah', 'Nyerah')) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete susunkata[from];
clearTimeout(waktu);
} else if (susunkata[from]) reply(`*WAKTU HABIS!*\n\nJawaban Dari Soal :\n${monospace(soal)}\n\nAdalah : ${monospace(jawaban)}`);
delete susunkata[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'tebakanime':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
var { image, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/tebakanime.json')));
console.log('Jawaban : '+jawaban)
var teks1 = `*GAME TEBAK ANIME*\n\nPetunjuk : ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nWaktu : ${gamewaktu} Detik\n\nKetik .nyerah Tuk Menyerah`
await Rifky.sendMessage(from, {image: {url: image}, caption: teks1}, {quoted: m})
tebakanime[from] = {
soal: image,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match(`nyerah`, `Nyerah`, `${prefix}nyerah`)) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebakanime[from];
clearTimeout(waktu);
} else if (tebakanime[from]) reply(`*WAKTU HABIS!*\nJawabannya Adalah : ${tebakanime[from].jawaban}`);
delete tebakanime[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'tebaklagu':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
var { soal, artis, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/tebaklagu.json')));
console.log('Jawaban : '+jawaban)
if (jawaban.toLowerCase() == 'Audio Tidak Ditemukan, Silahkan Request Ulang!') return reply('Maaf Terjadi Kesalahan!')
var teks1 = `*GAME TEBAK LAGU*\n\nPetunjuk : ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nArtis : ${artis}\nWaktu : ${gamewaktu} Detik\n\nKetik .nyerah Tuk Menyerah`
Rifky.sendMessage(from, {audio: {url: soal}, mimetype: 'audio/mpeg', ptt: true}, {quoted: m})
await Rifky.sendMessage(from, {text: teks1}, {quoted:m})
tebaklagu[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match(`nyerah`, `Nyerah`, `${prefix}nyerah`)) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebaklagu[from];
clearTimeout(waktu);
} else if (tebaklagu[from]) reply(`*WAKTU HABIS!*\nJawabannya Adalah : ${tebaklagu[from].jawaban}`);
delete tebaklagu[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'kuis':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (from in kuis) return reply('Masih Ada Game Yang Belum Diselesaikan!');
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/kuis.json')));
console.log('Jawaban : '+jawaban)
await reply(`*GAME KUIS*\n\nSoal : ${soal}\nPetunjuk : ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nWaktu : ${gamewaktu} Detik\n\nKetik .nyerah Tuk Menyerah`)
kuis[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match(`nyerah`, `Nyerah`, `${prefix}nyerah`)) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete kuis[from];
clearTimeout(waktu);
} else if (kuis[from]) reply(`*WAKTU HABIS!*\n\nJawaban Dari Soal :\n${monospace(soal)}\n\nAdalah : ${monospace(jawaban)}`);
delete kuis[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'tebakkata':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (from in tebakkata) return reply('Masih Ada Game Yang Belum Diselesaikan!');
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/tebakkata.json')));
console.log('Jawaban : '+jawaban)
await reply(`*GAME tebakkata*\n\nSoal : ${soal}\nPetunjuk : ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nWaktu : ${gamewaktu} Detik\n\nKetik .nyerah`)
tebakkata[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match(`nyerah`, `Nyerah`, `${prefix}nyerah`)) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebakkata[from];
clearTimeout(waktu);
} else if (tebakkata[from]) reply(`*WAKTU HABIS!*\n\nJawaban Dari Soal :\n${monospace(soal)}\n\nAdalah : ${monospace(jawaban)}`);
delete tebakkata[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'tebakkimia':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (from in tebakkimia) return reply('Masih Ada Game Yang Belum Diselesaikan!');
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/tebakkimia.json')));
console.log('Jawaban : '+jawaban)
await reply(`*GAME TEBAK KIMIA*\n\nSoal : ${soal}\nWaktu : ${gamewaktu} Detik\n\nKetik .nyerah Tuk Menyerah`)
tebakkimia[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match(`nyerah`, `Nyerah`, `${prefix}nyerah`)) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete tebakkimia[from];
clearTimeout(waktu);
} else if (tebakkimia[from]) reply(`*WAKTU HABIS!*\nNama Unsur Dari Lambang ${soal}\n\nAdalah : ${monospace(jawaban)}`)
delete tebakkimia[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'asahotak':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (from in asahotak) return reply('Masih Ada Game Yang Belum Diselesaikan!');
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/asahotak.json')));
console.log('Jawaban : '+jawaban)
await reply(`*GAME ASAH OTAK*\n\nSoal : ${soal}\nPetunjuk : ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nWaktu : ${gamewaktu} Detik\n\nKetik .nyerah Tuk Menyerah`)
asahotak[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match(`nyerah`, `Nyerah`, `${prefix}nyerah`)) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete asahotak[from];
clearTimeout(waktu);
} else if (asahotak[from]) reply(`*WAKTU HABIS!*\n\nJawaban Dari Soal :\n${monospace(soal)}\n\nAdalah : ${monospace(jawaban)}`);
delete asahotak[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'siapakahaku': 
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (from in siapakahaku) return reply('Masih Ada Game Yang Belum Diselesaikan!');
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/siapakahaku.json')));
console.log('Jawaban : '+jawaban)
await reply(`*GAME SIAPAKAH AKU*\n\nSoal : ${soal}\nPetunjuk : ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nWaktu : ${gamewaktu} Detik\n\nKetik .nyerah Tuk Menyerah`)
siapakahaku[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (budy.match(`nyerah`, `Nyerah`, `${prefix}nyerah`)) {
reply(`*KAMU NENYERAH*\n\nJawabannya Adalah *${jawaban}*`);
delete siapakahaku[from];
clearTimeout(waktu);
} else if (siapakahaku[from]) reply(`*WAKTU HABIS!*\n\nJawaban Dari Soal :\n${monospace(soal)}\n\nAdalah : ${monospace(jawaban)}`);
delete siapakahaku[from];
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'family100': 
case 'f100':
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./database/game/family100.json')));
console.log('Jawaban : '+jawaban)
let famil = []
for (let i of jawaban){
let fefsh = i.split('/') ? i.split('/')[0] : i
let iuhbs = fefsh.startsWith(' ') ? fefsh.replace(' ','') : fefsh
let axsfh = iuhbs.endsWith(' ') ? iuhbs.replace(iuhbs.slice(-1), '') : iuhbs
famil.push(axsfh.toLowerCase())
}
await reply(`*GAME FAMILY 100*\n\nSoal : ${soal}\nTotal Jawaban : ${jawaban.length}\n\nWaktu : ${gamewaktu} Detik`)
family100[from] = {
soal: soal,
jawaban: famil,
hadiah: randomNomor(10, 20),
waktu: setTimeout(async function () {
let jwb = family100[from].jawaban
if (from in family100) {
let teks = `*WAKTU HABIS!*\nJawaban Yang Belum Terjawab :\n`
for (let i of jwb){teks += `\n${i}`}
reply(teks)
delete family100[from];
};
}, gamewaktu * 1000)
}
limitAdd(m.sender, db_limit)
break

















//===================[ TEMPAT CASE MENU DOWNLOAD ]=====================\\

 










case 'ttsearch':
case 'tts':
case 'tiktoks': {
Rifky.sendMessage(from, {
		react: {
			text: "🔎",
			key: m.key
		}
	})
  if (!text) return reply('masukkan subjek video!')
  try {
    let tts = await (await fetch(`https://api.shannmoderz.xyz/search/tiktok?query=${text}`)).json()
    let cukii = tts.result
    Rifky.sendMessage(m.chat, {
  video: {url: cukii.no_watermark},
  gifPlayback: false, 
  caption: cukii.title
  }, {quoted: m})
  } catch (err) {
      reply('masukkan query lainnya atau coba lagi nanti')
    }
}
break

//=========================\\
case 'instagram': case 'ig': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
	if (!text) return reply(`Masukan Link Nya!!!`)
	if (!isUrl(args[0])) return reply(`Apakah Itu Terlihat Seperti Link?`)
	await Rifky.sendMessage(m.chat, {
		react: {
			text: "⏱️",
			key: m.key,
		}
	})
	try {
		let anu = await fetchJson(`https://widipe.com/download/igdl?url=${text}`)
		Rifky.sendMessage(m.chat, {
			video: {
				url: anu.result[0].url
			},
			caption: `_Sukses Mengunduh Video_`
		}, {
			quoted: m
		})
		await Rifky.sendMessage(m.chat, {
			react: {
				text: "☑️",
				key: m.key,
			}
		})
	} catch (error) {
		await Rifky.sendMessage(m.chat, {
			react: {
				text: "✖️",
				key: m.key,
			}
		})
	}
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'facebook': case 'fb': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
	if (!text) return reply(`Masukan Link Nya!!!`)
	if (!isUrl(args[0])) return reply(`Apakah Itu Terlihat Seperti Link?`)
	await Rifky.sendMessage(m.chat, {
		react: {
			text: "⏱️",
			key: m.key,
		}
	})
	try {
		let anu = await fetchJson(`https://widipe.com/download/fbdown?url=${text}`)
		Rifky.sendMessage(m.chat, {
			video: {
				url: anu.result.url.urls[0].hd
			},
			caption: `_Sukses Mengunduh Video Kak ${pushname}_`
		}, {
			quoted: m
		})
		await Rifky.sendMessage(m.chat, {
			react: {
				text: "☑️",
				key: m.key,
			}
		})
	} catch (error) {
		await Rifky.sendMessage(m.chat, {
			react: {
				text: "✖️",
				key: m.key,
			}
		})
	}
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'tiktok':
case 'tt':
case 'ttdl': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
	const api = require('btch-downloader')
	if (!args[0]) return reply(`Masukan URL!\n\ncontoh:\n${prefix + command} https://vm.tiktok.com/ZGJAmhSrp/`);
	if (!args[0].match(/tiktok/gi)) return reply(`URL Yang Tuan Berikan *Salah!!!*`);
	let maximus = await api.ttdl(args[0]);
	let caption = `乂 *T I K T O K  D O W N L O A D* 

• *ɴᴀᴍᴀ ᴠɪᴅᴇᴏs:* 
${maximus.title}

• *ɴᴀᴍᴀ ᴀᴜᴅɪᴏ:* 
${maximus.title_audio}

© ᴍᴀᴅᴇ ʙʏ ʀɪғᴋʏ ᴍᴅ`;
	await Rifky.sendMessage(m.chat, {
		video: {
			url: maximus.video[0]
		},
		caption: caption
	})
	await Rifky.sendFile(m.chat, maximus.audio[0], 'kasar.mp3', null, m)
}
limitAdd(m.sender, db_limit)
break

case'mediafire': case'mfire': case'mfdl':{
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!text) return reply(`Gunakan dengan cara ${prefix+command} *url*`)
if (!isUrl(text)) return reply('Link yang kamu berikan tidak valid')
if (!text.includes('mediafire.com')) return reply('Link yang kamu berikan tidak valid')
await Rifky.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})   
kotz.mediafire(text).then(async(data) => {
data = data[0]
data.nama = decodeURIComponent(data.nama)
var media = await getBuffer(data.link)
if (data.mime.includes('mp4')) {
Rifky.sendMessage(m.chat, { document: media, fileName: data.nama, mimetype: 'video/mp4' }, { quoted: m })
} else if (data.mime.includes('mp3')) {
Rifky.sendMessage(m.chat, { document: media, fileName: data.nama, mimetype: 'audio/mp3' }, { quoted: m })
} else {
Rifky.sendMessage(m.chat, { document: media, fileName: data.nama, mimetype: 'application/'+data.mime }, { quoted: m })
}
}).catch((e) => {
console.log(color('[ ERROR ]', 'red'), e)
reply('Yah,ada kesalahan kak segera hubungi owner ya agar di perbaiki')
})}
limitAdd(m.sender, db_limit)
break



















//===================[ TEMPAT CASE MENU GROUP ]=====================\\



case 'open': case 'buka': {
Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!isBotAdmins) return reply("Bot bukan admin")
Rifky.groupSettingUpdate(m.chat, 'not_announcement')
const textOpen = await getTextSetOpen(m.chat, set_open);
reply(textOpen || `Sukses Mengizinkan Semua Peserta Dapat Mengirim Pesan Ke Grup Ini`)
}
break

case 'close': case 'tutup': {
Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!isBotAdmins) return reply("Bot bukan admin")
Rifky.groupSettingUpdate(m.chat, 'announcement')
const textClose = await getTextSetClose(m.chat, set_close);
reply(textClose || `Sukses Mengizinkan Hanya Admin Yang Dapat Mengirim Pesan Ke Grup Ini`)
}
break

case 'totag':{
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins && !isCreator) return reply('Lu Siapa Kocak')
let users = participants.map(u => u.id).filter(v => v !== Rifky.user.jid)
if (!m.quoted) throw `Reply Pesan`
await Rifky.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: users } )
}
break

case 'opentime': {
if (!isAdmins) return admin();
if (!isBotAdmins) return botAdmin();
const timeUnits = {
detik: 1000,
menit: 60000,
jam: 3600000,
hari: 86400000
};
const unit = args[1]?.toLowerCase();
const multiplier = timeUnits[unit];
const duration = parseInt(args[0]);
if (!multiplier || isNaN(duration) || duration <= 0) {
return reply(`Pilih:\nDetik\nMenit\nJam\nHari\n\nContoh: ${prefix+command} 10 detik`);
}
const timer = duration * multiplier;
reply(`Open time ${duration} ${unit} dimulai dari sekarang!`);
const sendReminder = (message, delay) => {
if (timer > delay) {
setTimeout(() => {
m.reply(message);
}, timer - delay);
}};
sendReminder(`Pengingat: 10 detik lagi grup akan dibuka!`, 10000);
setTimeout(() => {
const open = `*[ OPEN TIME ]* Grup telah dibuka!`;
Rifky.groupSettingUpdate(from, 'not_announcement');
reply(open);
}, timer);
}
break

case 'closetime': {
if (!isAdmins) return admin();
if (!isBotAdmins) return botAdmin();
const timeUnits = {
detik: 1000,
menit: 60000,
jam: 3600000,
hari: 86400000
};
const unit = args[1]?.toLowerCase();
const multiplier = timeUnits[unit];
const duration = parseInt(args[0]);
if (!multiplier || isNaN(duration) || duration <= 0) {
return reply(`Pilih:\nDetik\nMenit\nJam\nHari\n\nContoh: ${prefix+command} 10 detik`);
}
const timer = duration * multiplier;
reply(`Close time ${duration} ${unit} dimulai dari sekarang!`);
const sendReminder = (message, delay) => {
if (timer > delay) {
setTimeout(() => {
reply(message);
}, timer - delay);
}};
sendReminder(`Pengingat: 10 detik lagi grup akan ditutup!`, 10000);
setTimeout(() => {
const close = `*[ CLOSE TIME ]* Grup telah ditutup!`;
Rifky.groupSettingUpdate(from, 'announcement');
reply(close);
}, timer);
}
break

















//===================[ TEMPAT CASE MENU FUN ]=====================\\

case 'runtime': {
  let lowq = `
┌─〔 R U N T I M E 〕
├ Bot Aktif Selama ${runtime(process.uptime())}
└────
    `
    reply(lowq)
      }
  break
//=========================\\
case 'speed': case 'ping':{
const used = process.memoryUsage()
                const cpus = os.cpus().map(cpu => {
                    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			        return cpu
                })
                const cpu = cpus.reduce((last, cpu, _, { length }) => {
                    last.total += cpu.total
                    last.speed += cpu.speed / length
                    last.times.user += cpu.times.user
                    last.times.nice += cpu.times.nice
                    last.times.sys += cpu.times.sys
                    last.times.idle += cpu.times.idle
                    last.times.irq += cpu.times.irq
                    return last
                }, {
                    speed: 0,
                    total: 0,
                    times: {
			            user: 0,
			            nice: 0,
			            sys: 0,
			            idle: 0,
			            irq: 0
                }
                })
                let timestamp = speed()
                let latensi = speed() - timestamp
                neww = performance.now()
                oldd = performance.now()
                respon = `
💻 Info Server
⬡-▸Ram: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}
⬡-▸Response Speed ${latensi.toFixed(4)} _Second_ 
⬡-▸${oldd - neww} _miliseconds_
⬡-▸Runtime : ${runtime(process.uptime())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
                `.trim()
	await Rifky.sendMessage(m.chat, {
text: respon, 
contextInfo: {
externalAdReply: {  
title: `Erin store`,
body: 'Erin store',
thumbnailUrl: kambing,
sourceUrl: `https://www.youtube.com/@CallMyKyy`,
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
break
//=========================\\
case 'del': case 'd': case 'delete': {
Rifky.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: true,
id: m.quoted.id,
participant: m.quoted.sender
}
})
}
break
//=========================\\
case 'afk':{
if (!m.isGroup) return reply('Fitur Group')
if (isAfkOn) return reply('Afk sudah diaktifkan sebelumnya')
let reason = text ? text : 'Tanpa Alasan'
afk.addAfkUser(m.sender, Date.now(), reason, _afk)
Rifky.sendTextWithMentions(m.chat, `@${m.sender.split('@')[0]} sedang afk\nAlasan : ${reason}`, m)
}
break
//=========================\\
case 'listcase': {
let { listCase } = require('./scrape/ListCase.js')
reply(listCase())
}
break
//=========================\\
case 'smeme': case 'stickermeme': case 'stickmeme': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!/webp/.test(mime) && /image/.test(mime)) {
if (!text) return replygcxeon(`Usage: ${prefix + command} text1|text2`)
let { TelegraPh } = require('./lib/uploader')

atas = text.split('|')[0] ? text.split('|')[0] : '-'
bawah = text.split('|')[1] ? text.split('|')[1] : '-'
mee = await Rifky.downloadAndSaveMediaMessage(quoted)

mem = await TelegraPh(mee)

meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`

memek = await Rifky.sendImageAsSticker(m.chat, meme, m, { packname: global.packname, author: global.author })


} else {
reply(`Send/reply image with caption ${prefix + command} text1|text2`)
}
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'stiker': case 'sticker': case 's': case 'stickergif': case 'sgif': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!quoted) return reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
let media = await Rifky.downloadAndSaveMediaMessage(quoted, + new Date * 1)
await Rifky.imgToSticker(m.chat, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(media)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
let media = await Rifky.downloadAndSaveMediaMessage(quoted, + new Date * 1)
await Rifky.vidToSticker(m.chat, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(media)
} else if (/sticker/.test(mime)) {
let media = await Rifky.downloadAndSaveMediaMessage(quoted, + new Date * 1)
await Rifky.sendStickerFromUrl(from, media, m, {packname: global.packname, author: global.author })
await fs.unlinkSync(media)
} else reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'swm': case 'steal': case 'stickerwm': case 'take':{
if (!args.join(" ")) return reply(`Where is the text?`)
const swn = args.join(" ")
const pcknm = swn.split("|")[0]
const atnm = swn.split("|")[1]
if (m.quoted.isAnimated === true) {
Rifky.downloadAndSaveMediaMessage(quoted, "gifee")
Rifky.sendMessage(m.chat, {sticker:fs.readFileSync("gifee.webp")}, m, { packname: pcknm, author: atnm })
} else if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await Rifky.sendImageAsSticker(m.chat, media, m, { packname: pcknm, author: atnm })
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Maximum 10 Seconds!')
let media = await quoted.download()
let encmedia = await Rifky.sendVideoAsSticker(m.chat, media, m, { packname: pcknm, author: atnm })
} else {
reply(`Photo/Video?`)
}
}
break
//=========================\\
case 'toimage':
            case 'toimg': {
            if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
                if (!/webp/.test(mime)) return reply(`Reply sticker with caption *${prefix + command}*`)
                let media = await Rifky.downloadAndSaveMediaMessage(qmsg)
                let ran = await getRandom('.png')
                exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) return err
                    let buffer = fs.readFileSync(ran)
                    Rifky.sendMessage(m.chat, {
                        image: buffer
                    }, {
                        quoted: m
                    })
                    fs.unlinkSync(ran)
                })

            }
            limitAdd(m.sender, db_limit)
            break
 //=========================\\
               case 'tourl': {
               if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
                let media = await Rifky.downloadAndSaveMediaMessage(qmsg)
                if (/image/.test(mime)) {
                    let anu = await TelegraPh(media)
                    reply(util.format(anu))
                } else if (!/image/.test(mime)) {
                    let anu = await UploadFileUgu(media)
                    reply(util.format(anu))
                }
                await fs.unlinkSync(media)

            }
            limitAdd(m.sender, db_limit)
            break            
//=========================\\
case 'readvo': case 'readviewonce': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!m.quoted) throw 'Reply gambar/video yang ingin Anda lihat'
  if (m.quoted.mtype !== 'viewOnceMessageV2') throw 'Ini bukan pesan view-once.'
  let msg = m.quoted.message
  let type = Object.keys(msg)[0]
  let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
  let buffer = Buffer.from([])
  for await (const chunk of media) {
    buffer = Buffer.concat([buffer, chunk])
  }
  if (/video/.test(type)) {
    return Rifky.sendFile(m.chat, buffer, 'media.mp4', msg[type].caption || '', m)
  } else if (/image/.test(type)) {
    return Rifky.sendFile(m.chat, buffer, 'media.jpg', msg[type].caption || '', m)
  }
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'qc': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
if (!quoted){
const getname = await Rifky.getName(mentionUser[0])
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": getname,
"photo": {
"url": ppuser
}
},
"text": quotedMsg.chats,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
Rifky.sendStimg(from, buffer, m, opt)
});
} else if (q) {
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": pushname,
"photo": {
"url": ppuser
}
},
"text": q,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
Rifky.sendStimg(from, buffer, m, opt)
});
} else {
reply(`Kirim perintah ${prefix+command} text atau reply pesan dengan perintah ${prefix+command}`)
}
}
limitAdd(m.sender, db_limit)
break


case 'hdimg':
case 'hdr': 
case 'remini': case 'hd': case 'hdr': { 
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
let q = m.quoted;
  if (!q) {
    return reply(`*[ ⚠️ ] Usage*\n${prefix + command} <reply to an image>\n\n*HANYA BISA REPLY*`);
  }
  let mime = (q.msg || q).mimetype || '';
  if (!mime.startsWith('image/')) {
    return reply(`*[ ⚠️ ] Usage*\n${prefix + command} <reply to an image>\n\n*HANYA BISA REPLY*`);
  }
try{
const { remini } = require('./scrape/remini')
let media = await quoted.download()
let proses = await remini(media, "enhance");
Rifky.sendMessage(m.chat, { image: proses, caption:'\n> Sukses'})
}catch (error) {
m.reply('erorr')
}}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'tovn': {
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
 if (!/video/.test(mime) && !/audio/.test(mime)) return reply (`Reply Video/Vn Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`)
if (!quoted) return reply (`Reply Video/Vn Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`)
await Rifky.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}
  })   
let media = await quoted.download()
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
Rifky.sendMessage(m.chat, {audio, mimetype:'audio/mpeg', ptt: true}, { quoted : m })
}
limitAdd(m.sender, db_limit)
break
//=========================================\\
case 'toaudio': case 'tomp3':{
if (isLimit(m.sender, isPremium, isCreator, limitCount, db_limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
 if (!/video/.test(mime) && !/audio/.test(mime)) return reply (`Reply Video/Vn Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`)
if (!quoted) return reply (`Reply Video/Vn Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`)
await Rifky.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}
  })   
let media = await quoted.download()
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
Rifky.sendMessage(m.chat, {audio, mimetype: 'audio/mpeg'}, { quoted : m })
}
limitAdd(m.sender, db_limit)
break
//=========================\\
case 'pin': case 'pinterest': {
Rifky.sendMessage(from, {react: {text: "🧐", key: m.key}})
if (!text) return reply(`*Example*: ${prefix + command} RifkyShre`)
  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: Rifky.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let push = [];
  let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
  let res = data.resource_response.data.results.map(v => v.images.orig.url);

  shuffleArray(res);
  let ult = res.splice(0, 10);
  let i = 1;

  for (let lucuy of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image dari ${text}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: 'RifkyShre'
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: 'Hasil.',
        hasMediaAttachment: true,
        imageMessage: await createImage(lucuy)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            "name": "cta_url",
            "buttonParamsJson": `{"display_text":"MY CHANEL OWNER","url":"https://whatsapp.com/channel/0029Vajc7fkBA1erCyF48I3k,"merchant_url":"https://www.google.com"}`
          }, {
            "name": "cta_url",
            "buttonParamsJson": `{"display_text":"SOURCE","url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}","merchant_url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}"}`
          }
        ]
      })
    });
  }

  const bot = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: mess.done
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'By RifkyShre'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {});

  await Rifky.relayMessage(m.chat, bot.message, {
    messageId: bot.key.id
  });
  
}
break
//=========================\\
case 'cekdrive': case'drive':
var result = await nou.drive.info();
reply(`*Drive Server Info*\n\n *• Total :* ${result.totalGb} GB\n *• Used :* ${result.usedGb} GB (${result.usedPercentage}%)\n *• Free :* ${result.freeGb} GB (${result.freePercentage}%)`)
break
case 'cekbandwidth': case'bandwidth':
var { download, upload } = await checkBandwidth();
reply(`*Bandwidth Server*\n\n*>* Upload : ${upload}\n*>* Download : ${download}`)
break

case 'cekodam':
case 'cekkodam':
case 'cekkhodam': {
if (!text) return m.reply(`Contoh: ${prefix+command} toya`)
const khodam = pickRandom([
"Kaleng Cat Avian",
"Pipa Rucika",
"Botol Tupperware",
"Badut Mixue",
"Sabun GIV",
"Sandal Swallow",
"Jarjit",
"Ijat",
"Fizi",
"Mail",
"Ehsan",
"Upin",
"Ipin",
"Sungut Lele",
"Tok Dalang",
"Opah",
"Opet",
"Alul",
"Pak Vinsen",
"Maman Resing",
"Pak RT",
"Admin ETI",
"Bung Towel",
"Lumpia Basah",
"Martabak Manis",
"Baso Tahu",
"Tahu Gejrot",
"Dimsum",
"Seblak Ceker",
"Telor Gulung",
"Tahu Aci",
"Tempe Mendoan",
"Nasi Kucing",
"Kue Cubit",
"Tahu Sumedang",
"Nasi Uduk",
"Wedang Ronde",
"Kerupuk Udang",
"Cilok",
"Cilung",
"Kue Sus",
"Jasuke",
"Seblak Makaroni",
"Sate Padang",
"Sayur Asem",
"Kromboloni",
"Marmut Pink",
"Belalang Mullet",
"Kucing Oren",
"Lintah Terbang",
"Singa Paddle Pop",
"Macan Cisewu",
"Vario Mber",
"Beat Mber",
"Supra Geter",
"Oli Samping",
"Knalpot Racing",
"Jus Stroberi",
"Jus Alpukat",
"Alpukat Kocok",
"Es Kopyor",
"Es Jeruk",
"Cappucino Cincau",
"Jasjus Melon",
"Teajus Apel",
"Pop ice Mangga",
"Teajus Gulabatu",
"Air Selokan",
"Air Kobokan",
"TV Tabung",
"Keran Air",
"Tutup Panci",
"Kotak Amal",
"Tutup Termos",
"Tutup Botol",
"Kresek Item",
"Kepala Casan",
"Ban Serep",
"Kursi Lipat",
"Kursi Goyang",
"Kulit Pisang",
"Warung Madura",
"Gorong-gorong",
"Tai Kuda",
"Tikus Kentut",
"Banteng Merah",
"Bajigur",
"Bakso Sumatra",
"Neymar Bogor",
"Christiano Rojali",
"Batagor",
"Seblak Kalimantan",
"Macan Putih",
"Harimau Sumatra",
"Harimau Putih",
"Singa",
"Raja Iblis",
"Telur Betawi",
"Cilok Goreng",
])
const response = `
${monospace("CEK  KHODAM")}
- Nama: ${text}
- Khodam: ${khodam}
`
m.reply(response)
try{
let tek = `Khodam nya ${text}, adalah: ${khodam}`
let anu = await fetchJson(`https://api.erdwpe.com/api/soundoftext?text=${tek}&lang=id-ID`)
const aud = anu.result
await sleep(50)
Rifky.sendMessage(m.chat, {audio : {url : aud}, mimetype:'audio/mpeg', ptt: true}, {quoted:m})
} catch(err) {
m.reply('Terjadi kesalahan')
}}
break











//==================[ TEMPAT MENU CASE PUSHKONTAK ]====================\\


case 'idgc':{
if (!isCreator) return reply(mess.OnlyOwner)
reply (`${m.chat}`)
}
break
case 'pushkontak':{
if (!isCreator) return reply(mess.OnlyOwner)
if (!m.isGroup) return m.reply(`di group coy`)
if (!text) return reply(`Teks Nya Kak?`)
let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let teksnye = `${q}`
reply(`*Mengirim pesan ke ${mem.length} orang, waktu selesai ${mem.length * 8} detik*`)
for (let geek of mem) {
await sleep(50000) //atur jeda
Rifky.sendMessage(geek, {text: `${teksnye}`}, {quoted:m})
}
reply(`*Sukses mengirim pesan Ke ${mem.length} orang*`)
}
break
case 'pushkontak2':{
if (!isCreator) return reply(mess.OnlyOwner)
let idgc = text.split("|")[0]
let pesan = text.split("|")[1]
if (!idgc && !pesan) return reply(`Example: ${prefix + command} idgc|pesan`)
let metaDATA = await Rifky.groupMetadata(idgc).catch((e) => reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
let count = getDATA.length;
let sentCount = 0;
reply(`*_Sedang Push ID..._*\n*_Mengirim pesan ke ${getDATA.length} orang, waktu selesai ${getDATA.length * 8} detik_*`)
for (let i = 0; i < getDATA.length; i++) {
setTimeout(function() {
Rifky.sendMessage(getDATA[i], { text: pesan });
count--;
sentCount++;
if (count === 0) {
reply(`*_Semua pesan telah dikirim!:_* *_✓_*\n*_Jumlah pesan terkirim:_* *_${sentCount}_*`);
}
}, i * 10000);//gw sgtu
}
}
break







//===================[ BATAS CASE ]=====================\\
default:


if ((budy) && ["proses", "Proses",].includes(budy) && !isCmd) {
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!m.quoted) return reply('Reply pesanan yang akan proses')
let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1]
let proses = `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM : @jam\n✨ STATUS : Pending\`\`\`\n\n📝 Catatan :\n@pesanan\n\nPesanan @user sedang di proses!`
const getTextP = getTextSetProses(m.chat, set_proses);
if (getTextP !== undefined) {
var anunya = (getTextP.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', timee).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0]))
Rifky.sendTextWithMentions(m.chat, anunya, m)
} else {
Rifky.sendTextWithMentions(m.chat, (proses.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', timee).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0])), m)}
}

if ((budy) && ['done', "Done"].includes(budy) && !isCmd) {
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins) return reply('Fitur Khusus admin!')
if (!m.quoted) return reply('Reply pesanan yang telah di proses')
let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1]
let sukses = `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM : @jam\n✨ STATUS : Berhasil\`\`\`\n\nTerimakasih @user Next Order ya🙏`
const getTextD = getTextSetDone(m.chat, set_done);
if (getTextD !== undefined) {
var anunya = (getTextD.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', timee).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0]))
Rifky.sendTextWithMentions(m.chat, anunya, m)
} else {
Rifky.sendTextWithMentions(m.chat, (sukses.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', timee).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0])), m)}
}

if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return reply(bang)
}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return reply(`${err}`)
if (stdout) return reply(stdout)
})
}
}

  
} catch (err) {
console.log(util.format(err))
}
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
